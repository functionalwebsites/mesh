# Offline Room PWA

Static PWA starter for offline/hotspot peer-to-peer rooms.

## What works now
- Offline cache via service worker
- Guided create/join flows
- WebRTC DataChannel connection using manual copy/paste signaling
- Local-network/hotspot-friendly config with no STUN/TURN servers
- Chat messages
- Basic file chunk sending
- Web Bluetooth support detection and picker demo

## Important browser limits
- A browser PWA cannot turn on hotspot, Wi-Fi Direct, or silently discover nearby rooms.
- Web Bluetooth cannot make ordinary browser phones advertise themselves as room beacons.
- Bluetooth room discovery needs a BLE peripheral/native app/ESP32-style beacon advertising a custom GATT service.
- Service workers require HTTPS or localhost. Do not expect file:// to install/cache as a PWA.

## Running locally
Use any static server:

```bash
npx http-server . -p 8080
```

Open http://localhost:8080

## Next steps to make QR real
This starter exposes pairing payloads. Add a vendored offline QR library, e.g. `qrcode-generator`, then render `offerOut` and `answerOut`. For scanning, add a camera QR scanner library or use BarcodeDetector where supported.

## Best field workflow
1. Creator turns on hotspot.
2. Joiners connect to hotspot.
3. Creator taps Create room offer.
4. Joiner pastes/scans offer and generates answer.
5. Creator accepts answer.
6. Chat/files now use WebRTC peer connection.
