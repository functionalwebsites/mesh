const $ = (id) => document.getElementById(id);
let installPrompt;
let pc;
let channel;
let peers = [];

const rtcConfig = { iceServers: [] }; // LAN/hotspot only. Add STUN for internet-assisted connections.

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  installPrompt = e;
  $('installBtn').hidden = false;
});
$('installBtn').onclick = async () => { if (installPrompt) await installPrompt.prompt(); };

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./service-worker.js').catch(console.warn);
}

document.querySelectorAll('[data-screen]').forEach(btn => btn.onclick = () => showScreen(btn.dataset.screen));
function showScreen(id){ document.querySelectorAll('.screen').forEach(s => s.hidden = true); $(id).hidden = false; }

function logMsg(text, me=false){
  const div=document.createElement('div'); div.className='msg'; div.textContent=(me?'Me: ':'Peer: ')+text; $('messages').appendChild(div); $('messages').scrollTop=999999;
}
function setStatus(text){ $('status').textContent = text; }
function pack(obj){ return btoa(unescape(encodeURIComponent(JSON.stringify(obj)))); }
function unpack(str){ return JSON.parse(decodeURIComponent(escape(atob(str.trim())))); }
async function waitForIce(peer){
  if (peer.iceGatheringState === 'complete') return;
  await new Promise(resolve => {
    peer.addEventListener('icegatheringstatechange', () => {
      if (peer.iceGatheringState === 'complete') resolve();
    });
  });
}
function attachChannel(dc){
  channel = dc;
  channel.binaryType = 'arraybuffer';
  channel.onopen = () => { $('room').hidden = false; setStatus('Connected'); logMsg('Connected to room system', true); };
  channel.onmessage = (ev) => {
    if (typeof ev.data === 'string') {
      const msg = JSON.parse(ev.data);
      if (msg.kind === 'chat') logMsg(msg.text);
      if (msg.kind === 'file-meta') logMsg(`Incoming file: ${msg.name} (${msg.size} bytes)`);
    } else {
      logMsg(`Received ${ev.data.byteLength} bytes of file data`);
    }
  };
  channel.onclose = () => setStatus('Disconnected');
}

$('createOfferBtn').onclick = async () => {
  pc = new RTCPeerConnection(rtcConfig);
  const dc = pc.createDataChannel('room');
  attachChannel(dc);
  pc.onconnectionstatechange = () => setStatus(pc.connectionState);
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  await waitForIce(pc);
  $('offerOut').value = pack({ role:'creator', room:$('roomName').value, sdp:pc.localDescription });
};

$('joinOfferBtn').onclick = async () => {
  const payload = unpack($('offerIn').value);
  pc = new RTCPeerConnection(rtcConfig);
  pc.ondatachannel = (ev) => attachChannel(ev.channel);
  pc.onconnectionstatechange = () => setStatus(pc.connectionState);
  await pc.setRemoteDescription(payload.sdp);
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  await waitForIce(pc);
  $('answerOut').value = pack({ role:'joiner', room:payload.room, sdp:pc.localDescription });
};

$('acceptAnswerBtn').onclick = async () => {
  const payload = unpack($('answerIn').value);
  await pc.setRemoteDescription(payload.sdp);
  $('room').hidden = false;
  setStatus('Answer accepted; connecting…');
};

$('sendBtn').onclick = () => {
  const text = $('messageText').value.trim();
  if (!text || !channel || channel.readyState !== 'open') return;
  channel.send(JSON.stringify({kind:'chat', text, at:Date.now()}));
  logMsg(text, true); $('messageText').value='';
};

$('sendFileBtn').onclick = async () => {
  const file = $('fileInput').files[0];
  if (!file || !channel || channel.readyState !== 'open') return;
  channel.send(JSON.stringify({kind:'file-meta', name:file.name, size:file.size, type:file.type}));
  const chunkSize = 16 * 1024;
  for (let offset=0; offset<file.size; offset+=chunkSize) {
    channel.send(await file.slice(offset, offset+chunkSize).arrayBuffer());
    while (channel.bufferedAmount > 1024 * 1024) await new Promise(r => setTimeout(r, 50));
  }
  logMsg(`Sent file: ${file.name}`, true);
};

document.querySelectorAll('[data-copy]').forEach(btn => btn.onclick = async () => navigator.clipboard.writeText($(btn.dataset.copy).value));
function showQRPayload(id){ $('qrPayload').value = $(id).value || 'No pairing code generated yet.'; $('qrDialog').showModal(); }
$('showOfferQR').onclick = () => showQRPayload('offerOut');
$('showAnswerQR').onclick = () => showQRPayload('answerOut');
$('closeQr').onclick = () => $('qrDialog').close();

$('btScanBtn').onclick = async () => {
  const out = $('btLog');
  if (!navigator.bluetooth) { out.textContent = 'Web Bluetooth is not available in this browser/device.'; return; }
  try {
    out.textContent = 'Opening Bluetooth picker…';
    const device = await navigator.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: ['battery_service'] });
    out.textContent = `Selected: ${device.name || '(unnamed)'}\nID: ${device.id}\nNote: browser cannot use this phone as a BLE room beacon without native/peripheral support.`;
  } catch (e) { out.textContent = e.message; }
};
